# Anonymous reproducibility supplement

Zero-call materials for "Before Candidate Selection in Test-Time LLM Agents".
Nothing here contacts a model provider.

## Regenerate the reported numbers

    cd repro
    python reanalyze_review_items.py          # writes research/data/review-response-reanalysis-231.json
    python candidate_support_cached_preview.py  # writes research/data/candidate-support-cached-preview-237.json
    python test_post_arr_persistence_analysis.py

`reanalyze_review_items.py` reproduces, from the cached per-run and per-task rows:

- the Table 3 counts, the pooled row, and generation/selection failures with exact intervals;
- the round-candidate-only versus final-inclusive oracle check and the IMPOSSIBLE-reference sensitivity;
- parser acceptance rates and final-answer metric agreement;
- the per-task C1-C5 patterns and oracle intervals plotted in Figure 2;
- the score-source and score-observation counts of Figure 1c;
- the exact bound for the degenerate initial-ablation bootstrap and the canary denominators.

`candidate_support_cached_preview.py` reproduces the random-final selector baselines
of Figure 2, the executable-validity versus reference-exactness comparison for the two
non-degenerate length-removal cohorts, and the parser-sensitivity calculation for the
generation-failure count. It reads no candidate text.

`figures/make_main_figures.py` redraws Figures 1-2 and the appendix figures (matplotlib).

## Contents

- `research/data/cached-analysis/`: cached zero-call analyses 037, 081, 088 and their protocols 080, 087.
- `research/data/`: the completed persistence replication summary (223), its analysis (222), and the candidate-support preview (237).
- `research/protocols/`: replication protocol 199 and its answer-free runner cohort 203.
- `repro/`: analysis, reanalysis, and test scripts.

## Not included

The upstream agent runtime (its license could not be confirmed), raw provider traces,
raw canary strings, and credentials. Live runs need a separate runtime checkout and
the frozen protocols. Internal project prefixes were removed from file names and
identifiers for anonymity; no number was changed.
